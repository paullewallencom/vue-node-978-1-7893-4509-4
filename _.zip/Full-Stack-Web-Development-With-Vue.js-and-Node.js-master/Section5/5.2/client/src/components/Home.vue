<template>
    <h1>Home</h1>
</template>
<script>
export default {
    
}
</script>
<style scoped>

</style>
