require('jsdom-global')()
global.expect = require('expect')
window.Date = Date;