var app = new Vue({
    el: '#app',
    data: {
        seen: false
    }
})