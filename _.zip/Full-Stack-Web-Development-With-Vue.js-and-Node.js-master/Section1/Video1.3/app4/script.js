var app = new Vue({
    el: '#app',
    data: {
        todos:[
            { text:'Learn JavaScript'},
            { text:'Learn Vue'},
            { text:'App1'},
            { text:'App2'}
        ]
    }
});