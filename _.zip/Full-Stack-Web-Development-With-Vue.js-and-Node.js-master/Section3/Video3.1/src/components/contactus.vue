<template>
    <div>
        <h1>Contact Us</h1>
        <p>This is my Contact page</p>
    </div>
</template>
<script>
export default {
    
}
</script>
<style>
</style>
