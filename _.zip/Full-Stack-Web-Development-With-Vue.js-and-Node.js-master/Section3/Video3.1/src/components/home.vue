<template>
    <div>
        <h1>Home</h1>
        <p>This is my Home page</p>
    </div>
</template>
<script>
export default {
    
}
</script>
<style>
</style>
