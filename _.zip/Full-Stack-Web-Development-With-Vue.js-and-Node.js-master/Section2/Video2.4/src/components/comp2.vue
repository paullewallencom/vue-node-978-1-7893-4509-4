<template>
    <h1>Component 2</h1>
</template>

<script>
export default {
    
}
</script>

<style scoped>
h1 {
    color:blue;
}
</style>
